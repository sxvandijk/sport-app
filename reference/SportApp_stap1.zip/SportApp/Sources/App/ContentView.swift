import SwiftUI

/// Startscherm: snel een lege training of een bestaand schema starten, of een lopende workout hervatten.
struct ContentView: View {
    @StateObject private var store = WorkoutStore()
    @State private var showingWorkout = false
    @State private var pendingStart: StartRequest?

    private struct StartRequest {
        let template: WorkoutTemplate?
    }

    var body: some View {
        NavigationStack {
            List {
                if let active = store.activeSession {
                    Section {
                        Button {
                            showingWorkout = true
                        } label: {
                            Label("Hervat \(active.name)", systemImage: "play.circle.fill")
                                .font(.headline)
                                .frame(minHeight: 44)
                        }
                    }
                }

                Section("Snel starten") {
                    Button {
                        requestStart(template: nil)
                    } label: {
                        Label("Lege training", systemImage: "plus.circle.fill")
                            .frame(minHeight: 44)
                    }
                }

                Section("Schema's") {
                    ForEach(store.templates) { template in
                        Button {
                            requestStart(template: template)
                        } label: {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(template.name)
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                Text("\(template.items.count) oefeningen")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            .frame(minHeight: 44, alignment: .leading)
                        }
                    }
                }
            }
            .navigationTitle("Training")
        }
        .fullScreenCover(isPresented: $showingWorkout) {
            ActiveWorkoutView(store: store) {
                showingWorkout = false
            }
        }
        .alert("Lopende workout vervangen?",
               isPresented: Binding(get: { pendingStart != nil },
                                    set: { if !$0 { pendingStart = nil } })) {
            Button("Vervangen", role: .destructive) {
                if let request = pendingStart { start(request.template) }
                pendingStart = nil
            }
            Button("Annuleer", role: .cancel) { pendingStart = nil }
        } message: {
            Text("Je hebt nog een workout open. Die gaat verloren als je een nieuwe start.")
        }
    }

    private func requestStart(template: WorkoutTemplate?) {
        if store.activeSession != nil {
            pendingStart = StartRequest(template: template)
        } else {
            start(template)
        }
    }

    private func start(_ template: WorkoutTemplate?) {
        store.startSession(template: template)
        showingWorkout = true
    }
}
