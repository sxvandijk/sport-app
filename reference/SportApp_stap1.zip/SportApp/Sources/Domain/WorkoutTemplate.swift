import Foundation

/// Een vast onderdeel van de warming-up, bv. "Externe rotatie (rotator cuff) – 2 × 15".
struct WarmupItem: Identifiable, Codable, Hashable {
    var id: UUID
    var name: String
    var prescription: String

    init(id: UUID = UUID(), name: String, prescription: String = "") {
        self.id = id
        self.name = name
        self.prescription = prescription
    }
}

struct TemplateItem: Identifiable, Codable, Hashable {
    var id: UUID
    var exerciseID: UUID
    var targetSets: Int
    var minReps: Int
    var maxReps: Int
    var restSeconds: Int
    /// Items die direct na elkaar staan en dezelfde groep hebben, vormen samen één superset.
    var supersetGroupID: UUID?

    init(id: UUID = UUID(),
         exerciseID: UUID,
         targetSets: Int = 3,
         minReps: Int = 8,
         maxReps: Int = 12,
         restSeconds: Int = 90,
         supersetGroupID: UUID? = nil) {
        self.id = id
        self.exerciseID = exerciseID
        self.targetSets = targetSets
        self.minReps = minReps
        self.maxReps = maxReps
        self.restSeconds = restSeconds
        self.supersetGroupID = supersetGroupID
    }
}

struct WorkoutTemplate: Identifiable, Codable, Hashable {
    var id: UUID
    var name: String
    /// De warming-up sectie is per workout optioneel.
    var warmupEnabled: Bool
    var warmup: [WarmupItem]
    var items: [TemplateItem]

    init(id: UUID = UUID(),
         name: String,
         warmupEnabled: Bool = true,
         warmup: [WarmupItem] = [],
         items: [TemplateItem] = []) {
        self.id = id
        self.name = name
        self.warmupEnabled = warmupEnabled
        self.warmup = warmup
        self.items = items
    }
}
