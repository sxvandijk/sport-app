import SwiftUI

/// "Machine bezet": toont direct (1) de app-suggestie, (2) jouw voorkeursalternatief en (3) zoeken.
/// Kiezen vervangt de oefening meteen; al ingevulde sets blijven bewaard.
struct QuickSwapSheetView: View {
    @ObservedObject var vm: ActiveWorkoutViewModel
    let sessionExerciseID: UUID
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                if let options = vm.swapOptions(for: sessionExerciseID) {
                    content(options)
                }
            }
            .navigationTitle("Machine bezet")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Annuleer") { dismiss() }
                }
            }
        }
    }

    @ViewBuilder
    private func content(_ options: SwapOptions) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Je wisselt \(options.current.name). Sets die je al hebt ingevuld blijven bewaard.")
                .font(.subheadline)
                .foregroundColor(.secondary)

            if let top = options.suggestions.first {
                SwapOptionCard(icon: "sparkles",
                               title: "Voorgesteld",
                               name: top.exercise.name,
                               detail: detail(for: top),
                               tint: .blue) {
                    choose(top.exercise)
                }
            } else {
                emptyCard("Geen geschikt alternatief gevonden in jouw gym.")
            }

            if let preferred = options.preferred {
                SwapOptionCard(icon: "star.fill",
                               title: "Jouw voorkeur",
                               name: preferred.exercise.name,
                               detail: preferred.isAvailable ? preferred.exercise.equipmentName : "Niet beschikbaar in jouw gym",
                               tint: .orange) {
                    choose(preferred.exercise)
                }
            } else {
                emptyCard("Geen voorkeursalternatief ingesteld voor deze oefening.")
            }

            let more = Array(options.suggestions.dropFirst().prefix(3))
            if !more.isEmpty {
                Text("Meer suggesties")
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(.secondary)
                    .padding(.top, 4)
                ForEach(more) { suggestion in
                    Button {
                        choose(suggestion.exercise)
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(suggestion.exercise.name)
                                    .foregroundColor(.primary)
                                Text(detail(for: suggestion))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        .padding(12)
                        .frame(minHeight: 48)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                    }
                    .buttonStyle(.plain)
                }
            }

            NavigationLink {
                ExercisePickerView(library: vm.library,
                                   gym: vm.gym,
                                   focusMuscle: options.current.primaryMuscle,
                                   excluding: Set(vm.session.exercises.map { $0.exerciseID }),
                                   onPick: { choose($0) })
            } label: {
                Label("Zoek andere oefening", systemImage: "magnifyingglass")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
            .padding(.top, 4)
        }
        .padding(16)
    }

    private func detail(for suggestion: AlternativeSuggester.Suggestion) -> String {
        if let machine = suggestion.equipmentName {
            return "\(suggestion.reason.label) · \(machine)"
        }
        return suggestion.reason.label
    }

    private func emptyCard(_ text: String) -> some View {
        Text(text)
            .font(.subheadline)
            .foregroundColor(.secondary)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
    }

    private func choose(_ exercise: Exercise) {
        vm.swapExercise(sessionExerciseID, to: exercise)
        dismiss()
    }
}

private struct SwapOptionCard: View {
    let icon: String
    let title: String
    let name: String
    let detail: String
    let tint: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundColor(tint)
                    .frame(width: 32)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title.uppercased())
                        .font(.caption2.weight(.bold))
                        .foregroundColor(tint)
                    Text(name)
                        .font(.headline)
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                    Text(detail)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()
                Image(systemName: "arrow.right.circle.fill")
                    .font(.title2)
                    .foregroundColor(tint)
            }
            .padding(14)
            .frame(minHeight: 72)
            .background(tint.opacity(0.10), in: RoundedRectangle(cornerRadius: 14))
        }
        .buttonStyle(.plain)
    }
}

/// Zoeklijst met alle oefeningen. Dezelfde spiergroep en oefeningen die in jouw gym kunnen staan bovenaan.
/// Wordt gebruikt voor "zoek andere oefening" en voor "oefening toevoegen".
struct ExercisePickerView: View {
    let library: ExerciseLibrary
    let gym: GymProfile?
    let focusMuscle: MuscleGroup?
    let excluding: Set<UUID>
    let onPick: (Exercise) -> Void

    @State private var query = ""

    var body: some View {
        List {
            ForEach(results) { exercise in
                Button {
                    onPick(exercise)
                } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(exercise.name)
                                .foregroundColor(.primary)
                            Text("\(exercise.primaryMuscle.displayName) · \(exercise.equipmentName)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        if !isAvailable(exercise) {
                            Text("niet in jouw gym")
                                .font(.caption2)
                                .foregroundColor(.orange)
                        }
                    }
                    .frame(minHeight: 40)
                }
            }
        }
        .searchable(text: $query, prompt: "Zoek oefening")
        .navigationTitle("Kies oefening")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func isAvailable(_ exercise: Exercise) -> Bool {
        gym?.supports(exercise) ?? true
    }

    private func rank(_ exercise: Exercise) -> Int {
        let sameMuscle = focusMuscle != nil && exercise.primaryMuscle == focusMuscle
        return (isAvailable(exercise) ? 0 : 2) + (sameMuscle ? 0 : 1)
    }

    private var results: [Exercise] {
        library.search(query)
            .filter { !excluding.contains($0.id) }
            .sorted { lhs, rhs in
                let l = rank(lhs)
                let r = rank(rhs)
                if l != r { return l < r }
                return lhs.name.localizedCaseInsensitiveCompare(rhs.name) == .orderedAscending
            }
    }
}
