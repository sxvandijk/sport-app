import SwiftUI

/// Het actieve workout-scherm.
/// Boven: duur + geschatte resterende tijd. Midden: warming-up, oefeningen en supersets.
/// Onder (duim-bereik): rusttimer en "Workout afronden".
struct ActiveWorkoutView: View {
    @StateObject private var vm: ActiveWorkoutViewModel
    @State private var showingFinishDialog = false
    private let onClose: () -> Void

    init(store: WorkoutStore, onClose: @escaping () -> Void) {
        _vm = StateObject(wrappedValue: ActiveWorkoutViewModel(store: store))
        self.onClose = onClose
    }

    var body: some View {
        VStack(spacing: 0) {
            WorkoutTopBar(vm: vm, onMinimize: onClose)
            Divider()
            ZStack(alignment: .bottom) {
                exerciseList
                bottomBar
            }
        }
        .background(Color(.systemBackground).ignoresSafeArea())
        .overlay(alignment: .top) { prBannerView }
        .animation(.easeInOut(duration: 0.25), value: vm.prBanner)
        .sheet(item: $vm.swapTarget) { target in
            QuickSwapSheetView(vm: vm, sessionExerciseID: target.id)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $vm.showingAddExercise) {
            addExerciseSheet
        }
        .confirmationDialog("Workout afronden?",
                            isPresented: $showingFinishDialog,
                            titleVisibility: .visible) {
            Button("Afronden en opslaan") {
                vm.finish()
                onClose()
            }
            Button("Workout weggooien", role: .destructive) {
                vm.discard()
                onClose()
            }
            Button("Doorgaan", role: .cancel) {}
        } message: {
            Text(vm.summaryText)
        }
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }

    private var exerciseList: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(spacing: 16) {
                    if !vm.session.warmup.isEmpty {
                        WarmupSectionView(vm: vm)
                    }
                    ForEach(vm.session.blocks) { block in
                        ExerciseBlockView(vm: vm, block: block)
                    }
                    Button {
                        vm.showingAddExercise = true
                    } label: {
                        Label("Oefening toevoegen", systemImage: "plus")
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                }
                .padding(.horizontal, 12)
                .padding(.top, 12)
                .padding(.bottom, 170)   // ruimte onder de laatste kaart voor de onderbalk
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: vm.scrollTarget) { target in
                guard let target = target else { return }
                withAnimation(.easeInOut(duration: 0.3)) {
                    proxy.scrollTo(target, anchor: .center)
                }
            }
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 10) {
            if let timer = vm.restTimer {
                RestTimerView(state: timer,
                              onAdjust: { vm.adjustRest(by: $0) },
                              onSkip: { vm.skipRest() })
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
            Button {
                showingFinishDialog = true
            } label: {
                Text("Workout afronden")
                    .font(.headline)
                    .frame(maxWidth: .infinity, minHeight: 50)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding(.horizontal, 12)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(.ultraThinMaterial, ignoresSafeAreaEdges: .bottom)
        .animation(.easeInOut(duration: 0.2), value: vm.restTimer)
    }

    @ViewBuilder
    private var prBannerView: some View {
        if let text = vm.prBanner {
            Label(text, systemImage: "trophy.fill")
                .font(.subheadline.weight(.semibold))
                .foregroundColor(.black)
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(Color.yellow.opacity(0.95), in: Capsule())
                .padding(.top, 70)
                .transition(.move(edge: .top).combined(with: .opacity))
        }
    }

    private var addExerciseSheet: some View {
        NavigationStack {
            ExercisePickerView(library: vm.library,
                               gym: vm.gym,
                               focusMuscle: nil,
                               excluding: [],
                               onPick: { exercise in
                                   vm.addExercise(exercise)
                                   vm.showingAddExercise = false
                               })
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Annuleer") { vm.showingAddExercise = false }
                    }
                }
        }
    }
}

/// Bovenbalk: verstreken tijd en geschatte resterende tijd, elke seconde bijgewerkt.
struct WorkoutTopBar: View {
    @ObservedObject var vm: ActiveWorkoutViewModel
    let onMinimize: () -> Void

    var body: some View {
        TimelineView(.periodic(from: Date(), by: 1)) { context in
            let estimate = vm.timeInfo(at: context.date)
            HStack(spacing: 8) {
                Button(action: onMinimize) {
                    Image(systemName: "chevron.down")
                        .font(.headline)
                        .frame(width: 44, height: 44)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(vm.session.name)
                        .font(.headline)
                    HStack(spacing: 6) {
                        Image(systemName: "timer")
                        Text(Format.clock(estimate.elapsed))
                            .monospacedDigit()
                        Text("·")
                        Text(Format.remainingText(estimate.remaining))
                    }
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                }
                Spacer()
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
        }
    }
}
