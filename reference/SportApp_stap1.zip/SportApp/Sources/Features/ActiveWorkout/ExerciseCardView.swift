import SwiftUI

/// Een blok in de workout: een losse oefening, of een superset (visueel gegroepeerd met kleurbalk).
struct ExerciseBlockView: View {
    @ObservedObject var vm: ActiveWorkoutViewModel
    let block: ExerciseBlock

    private let letters = ["A", "B", "C", "D", "E", "F"]

    var body: some View {
        if block.isSuperset {
            let color = vm.supersetColor(for: block.exercises.first?.supersetGroupID)
            HStack(spacing: 0) {
                Rectangle()
                    .fill(color)
                    .frame(width: 6)
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 6) {
                        Image(systemName: "link")
                        Text("SUPERSET")
                            .font(.caption.weight(.bold))
                        Text("rust na de laatste oefening")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .foregroundColor(color)
                    .padding(.horizontal, 12)
                    .padding(.top, 10)

                    ForEach(Array(block.exercises.enumerated()), id: \.element.id) { index, item in
                        if index > 0 { Divider().padding(.horizontal, 12) }
                        ExerciseCardView(vm: vm, exercise: item, tag: letters[min(index, letters.count - 1)], tint: color)
                    }
                }
            }
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 16))
        } else if let item = block.exercises.first {
            ExerciseCardView(vm: vm, exercise: item, tag: nil, tint: .accentColor)
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 16))
        }
    }
}

struct ExerciseCardView: View {
    @ObservedObject var vm: ActiveWorkoutViewModel
    let exercise: SessionExercise
    let tag: String?
    let tint: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            header
            columnHeader
            ForEach(Array(exercise.sets.enumerated()), id: \.element.id) { index, workoutSet in
                VStack(alignment: .leading, spacing: 0) {
                    SetRowView(vm: vm, exercise: exercise, workoutSet: workoutSet, label: setLabel(at: index))
                    // Na een "machine bezet"-wissel blijven afgeronde sets bij hun eigen oefening staan.
                    if workoutSet.exerciseID != exercise.exerciseID,
                       let original = vm.library[workoutSet.exerciseID] {
                        Text("gedaan op \(original.name)")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                            .padding(.leading, 30)
                    }
                }
            }
            footer
        }
        .padding(12)
    }

    private var header: some View {
        let info = vm.exercise(for: exercise)
        return HStack(alignment: .top, spacing: 8) {
            if let tag = tag {
                Text(tag)
                    .font(.caption.weight(.heavy))
                    .foregroundColor(.white)
                    .frame(width: 22, height: 22)
                    .background(tint, in: Circle())
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(info?.name ?? "Onbekende oefening")
                    .font(.headline)
                Text(subtitle(info))
                    .font(.caption)
                    .foregroundColor(.secondary)
                if exercise.wasSwapped, let original = vm.library[exercise.plannedExerciseID] {
                    Label("Gewisseld van \(original.name)", systemImage: "arrow.triangle.2.circlepath")
                        .font(.caption)
                        .foregroundColor(.orange)
                }
            }
            Spacer(minLength: 0)
            menu
        }
    }

    private func subtitle(_ info: Exercise?) -> String {
        let working = exercise.sets.filter { !$0.isWarmup }.count
        let target = "\(working) × \(exercise.targetRepsMin)–\(exercise.targetRepsMax)"
        let machine = vm.equipment(for: exercise)?.name ?? info?.equipmentName
        if let machine = machine { return "\(machine) · \(target)" }
        return target
    }

    private var menu: some View {
        Menu {
            Button {
                vm.addSet(to: exercise.id, warmup: true)
            } label: {
                Label("Warm-up set toevoegen", systemImage: "flame")
            }
            Button {
                vm.linkWithPrevious(exercise.id)
            } label: {
                Label("Superset met vorige oefening", systemImage: "link")
            }
            if exercise.supersetGroupID != nil {
                Button {
                    vm.unlinkSuperset(exercise.id)
                } label: {
                    Label("Uit superset halen", systemImage: "xmark.circle")
                }
            }
            Button(role: .destructive) {
                vm.removeExercise(exercise.id)
            } label: {
                Label("Verwijder oefening", systemImage: "trash")
            }
        } label: {
            Image(systemName: "ellipsis.circle")
                .font(.title3)
                .frame(width: 44, height: 32)
        }
    }

    private var columnHeader: some View {
        HStack(spacing: 6) {
            Text("SET").frame(width: 22)
            Text("KG").frame(maxWidth: .infinity)
            Text("REPS").frame(maxWidth: .infinity)
            Spacer().frame(width: 44)
        }
        .font(.caption2.weight(.semibold))
        .foregroundColor(.secondary)
        .padding(.horizontal, 4)
    }

    /// Onderaan de kaart, dus makkelijk bereikbaar met je duim.
    private var footer: some View {
        HStack(spacing: 8) {
            Button {
                vm.addSet(to: exercise.id)
            } label: {
                Label("Set", systemImage: "plus")
                    .frame(maxWidth: .infinity, minHeight: 36)
            }
            .buttonStyle(.bordered)

            Button {
                vm.swapTarget = SwapTarget(id: exercise.id)
            } label: {
                Label("Machine bezet", systemImage: "arrow.triangle.2.circlepath")
                    .frame(maxWidth: .infinity, minHeight: 36)
            }
            .buttonStyle(.bordered)
            .tint(.orange)
        }
    }

    private func setLabel(at index: Int) -> String {
        if exercise.sets[index].isWarmup { return "W" }
        let number = exercise.sets[...index].filter { !$0.isWarmup }.count
        return String(number)
    }
}
