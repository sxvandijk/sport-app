import SwiftUI

/// Vaste, optionele warming-up sectie (bv. rotator cuffs). Klapt automatisch in als alles is afgevinkt.
struct WarmupSectionView: View {
    @ObservedObject var vm: ActiveWorkoutViewModel
    @State private var expanded = true

    var body: some View {
        let entries = vm.session.warmup
        let doneCount = entries.filter { $0.isDone }.count
        let allDone = !entries.isEmpty && doneCount == entries.count

        VStack(spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { expanded.toggle() }
            } label: {
                HStack {
                    Image(systemName: "flame.fill")
                        .foregroundColor(.orange)
                    Text("Warming-up")
                        .font(.headline)
                    Spacer()
                    Text("\(doneCount)/\(entries.count)")
                        .monospacedDigit()
                        .foregroundColor(.secondary)
                    Image(systemName: "chevron.down")
                        .rotationEffect(.degrees(expanded ? 0 : -90))
                        .foregroundColor(.secondary)
                }
                .padding(12)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if expanded {
                Divider()
                ForEach(entries) { entry in
                    Button {
                        vm.toggleWarmupEntry(entry.id)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: entry.isDone ? "checkmark.circle.fill" : "circle")
                                .font(.title2)
                                .foregroundColor(entry.isDone ? .green : .secondary)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(entry.name)
                                    .strikethrough(entry.isDone)
                                    .foregroundColor(entry.isDone ? .secondary : .primary)
                                if !entry.prescription.isEmpty {
                                    Text(entry.prescription)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                            Spacer()
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 10)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .onChange(of: allDone) { finished in
            if finished {
                withAnimation(.easeInOut(duration: 0.2)) { expanded = false }
            }
        }
    }
}
