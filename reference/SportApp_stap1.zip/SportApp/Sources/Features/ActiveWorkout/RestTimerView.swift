import SwiftUI

/// Subtiele banner onderin met aftellen, ±15 s en overslaan. De haptic en melding komen uit de ViewModel.
struct RestTimerView: View {
    let state: RestTimerState
    let onAdjust: (Int) -> Void
    let onSkip: () -> Void

    var body: some View {
        TimelineView(.periodic(from: Date(), by: 0.5)) { context in
            let remaining = max(0, state.endsAt.timeIntervalSince(context.date))
            let finished = state.isFinished || remaining <= 0
            let progress = state.totalSeconds > 0 ? 1 - remaining / Double(state.totalSeconds) : 1

            VStack(spacing: 8) {
                HStack(spacing: 10) {
                    Image(systemName: finished ? "checkmark.circle.fill" : "timer")
                        .foregroundColor(finished ? .green : .secondary)
                    VStack(alignment: .leading, spacing: 0) {
                        Text(finished ? "Klaar – volgende set" : Format.clock(remaining.rounded(.up)))
                            .font(.headline.monospacedDigit())
                        Text(state.label)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                    Spacer()
                    if !finished {
                        pill("−15") { onAdjust(-15) }
                        pill("+15") { onAdjust(15) }
                    }
                    Button(action: onSkip) {
                        Image(systemName: "xmark")
                            .font(.footnote.weight(.bold))
                            .foregroundColor(.secondary)
                            .frame(width: 36, height: 36)
                    }
                    .buttonStyle(.plain)
                }
                ProgressView(value: min(max(progress, 0), 1))
                    .tint(finished ? .green : .accentColor)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private func pill(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.footnote.weight(.semibold))
                .frame(width: 48, height: 34)
                .background(Color(.tertiarySystemFill), in: Capsule())
        }
        .buttonStyle(.plain)
    }
}
