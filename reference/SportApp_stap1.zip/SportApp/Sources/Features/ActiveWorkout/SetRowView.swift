import SwiftUI

/// Eén compacte set-rij: [set] [− kg +] [− reps +] [✓]
/// Grote tikdoelen (≥ 40 pt) en de afvinkknop rechts, voor bediening met één hand.
struct SetRowView: View {
    @ObservedObject var vm: ActiveWorkoutViewModel
    let exercise: SessionExercise
    let workoutSet: WorkoutSet
    let label: String

    var body: some View {
        let hint = vm.placeholder(for: exercise, set: workoutSet)
        let done = workoutSet.isCompleted

        HStack(spacing: 6) {
            Text(label)
                .font(.subheadline.weight(.semibold))
                .foregroundColor(workoutSet.isWarmup ? .orange : .secondary)
                .frame(width: 22)

            StepperField(onMinus: { vm.stepWeight(workoutSet.id, up: false) },
                         onPlus: { vm.stepWeight(workoutSet.id, up: true) }) {
                NumberField(value: weightBinding,
                            placeholder: hint.weight.map { Format.weight($0) } ?? "–",
                            maxFractionDigits: 2)
                    .frame(minHeight: 40)
            }

            StepperField(onMinus: { vm.stepReps(workoutSet.id, up: false) },
                         onPlus: { vm.stepReps(workoutSet.id, up: true) }) {
                NumberField(value: repsBinding,
                            placeholder: hint.reps.map { String($0) } ?? "–",
                            maxFractionDigits: 0)
                    .frame(minHeight: 40)
            }

            Button {
                vm.toggleComplete(workoutSet.id)
            } label: {
                Image(systemName: "checkmark")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(done ? .white : .secondary)
                    .frame(width: 44, height: 40)
                    .background(done ? Color.green : Color(.tertiarySystemFill),
                                in: RoundedRectangle(cornerRadius: 10))
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 3)
        .padding(.horizontal, 4)
        .background(rowBackground(done: done))
        .id(workoutSet.id)
        .contextMenu {
            if !done {
                Button {
                    vm.toggleWarmupFlag(workoutSet.id)
                } label: {
                    Label(workoutSet.isWarmup ? "Maak werkset" : "Markeer als warm-up", systemImage: "flame")
                }
            }
            Button(role: .destructive) {
                vm.removeSet(workoutSet.id)
            } label: {
                Label("Verwijder set", systemImage: "trash")
            }
        }
    }

    private func rowBackground(done: Bool) -> some View {
        let color: Color
        if done {
            color = Color.green.opacity(0.12)
        } else if vm.attentionSetID == workoutSet.id {
            color = Color.red.opacity(0.18)
        } else {
            color = Color.clear
        }
        return RoundedRectangle(cornerRadius: 10).fill(color)
    }

    private var weightBinding: Binding<Double?> {
        Binding(
            get: { workoutSet.weight },
            set: { vm.setWeight(workoutSet.id, $0) }
        )
    }

    private var repsBinding: Binding<Double?> {
        Binding(
            get: { workoutSet.reps.map { Double($0) } },
            set: { newValue in
                let reps = newValue.map { Int(min(max($0, 0), 999)) }
                vm.setReps(workoutSet.id, reps)
            }
        )
    }
}

private struct StepperField<Content: View>: View {
    let onMinus: () -> Void
    let onPlus: () -> Void
    let content: Content

    init(onMinus: @escaping () -> Void,
         onPlus: @escaping () -> Void,
         @ViewBuilder content: () -> Content) {
        self.onMinus = onMinus
        self.onPlus = onPlus
        self.content = content()
    }

    var body: some View {
        HStack(spacing: 2) {
            StepButton(systemName: "minus", action: onMinus)
            content.frame(maxWidth: .infinity)
            StepButton(systemName: "plus", action: onPlus)
        }
    }
}

private struct StepButton: View {
    let systemName: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 14, weight: .bold))
                .frame(width: 30, height: 40)
                .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
    }
}
