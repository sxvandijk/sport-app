import SwiftUI

struct SwapTarget: Identifiable {
    let id: UUID   // id van de SessionExercise die gewisseld wordt
}

struct RestTimerState: Equatable, Identifiable {
    let id = UUID()
    var endsAt: Date
    var totalSeconds: Int
    var label: String
    var isFinished = false
}

struct SetPlaceholder {
    var weight: Double?
    var reps: Int?
}

struct SwapOptions {
    let current: Exercise
    let suggestions: [AlternativeSuggester.Suggestion]
    let preferred: (exercise: Exercise, isAvailable: Bool)?
}

private struct PerformanceKey: Hashable {
    let exerciseID: UUID
    let equipmentID: UUID?
}

/// Eigenaar van de lopende workout zolang het scherm open is. Elke wijziging wordt direct bewaard.
final class ActiveWorkoutViewModel: ObservableObject {

    @Published private(set) var session: ActiveWorkoutSession
    @Published private(set) var restTimer: RestTimerState? = nil
    @Published private(set) var prBanner: String? = nil
    @Published private(set) var attentionSetID: UUID? = nil
    @Published var swapTarget: SwapTarget? = nil
    @Published var showingAddExercise = false
    /// Set waar het scherm naartoe moet scrollen (bv. de volgende oefening in een superset).
    @Published var scrollTarget: UUID? = nil

    let library: ExerciseLibrary
    let gym: GymProfile?

    private let store: WorkoutStore
    private let history: WorkoutHistory
    private let estimator: DurationEstimator
    private var records: [UUID: ExerciseRecord]
    private var performanceCache: [PerformanceKey: [WorkoutSet]] = [:]
    private var restTicker: Timer?
    private var prBannerToken = UUID()
    private var isClosed = false

    init(store: WorkoutStore) {
        let current = store.activeSession
            ?? ActiveWorkoutSession.make(from: nil, gym: store.activeGym, library: store.library)

        self.store = store
        self.library = store.library
        self.gym = store.gym(withID: current.gymID) ?? store.activeGym
        self.session = current
        self.history = store.history
        self.records = PRService.records(from: store.data.history)
        let calibrated = DurationEstimator.calibratedSetSeconds(from: store.data.history)
        self.estimator = DurationEstimator(assumedSetSeconds: calibrated ?? 45)

        if store.activeSession == nil {
            store.persist(activeSession: current)
        }
    }

    deinit {
        restTicker?.invalidate()
    }

    // MARK: - Lezen

    func timeInfo(at date: Date) -> DurationEstimator.Estimate {
        estimator.estimate(for: session, at: date)
    }

    func exercise(for item: SessionExercise) -> Exercise? {
        library[item.exerciseID]
    }

    func equipment(for item: SessionExercise) -> GymEquipment? {
        guard let id = item.gymEquipmentID else { return nil }
        return gym?.equipment(withID: id)
    }

    func weightScale(for item: SessionExercise) -> WeightScale {
        if let machine = equipment(for: item) { return machine.scale }
        if let info = exercise(for: item),
           EquipmentType.type(withID: info.equipmentTypeID)?.isAlwaysAvailable == true {
            return .bodyweight
        }
        return .fallback
    }

    func supersetColor(for groupID: UUID?) -> Color {
        guard let groupID = groupID else { return .clear }
        var seen: [UUID] = []
        for item in session.exercises {
            if let group = item.supersetGroupID, !seen.contains(group) { seen.append(group) }
        }
        let palette: [Color] = [.blue, .purple, .orange, .teal, .pink, .indigo]
        let index = seen.firstIndex(of: groupID) ?? 0
        return palette[index % palette.count]
    }

    private func lastPerformance(for item: SessionExercise) -> [WorkoutSet] {
        let key = PerformanceKey(exerciseID: item.exerciseID, equipmentID: item.gymEquipmentID)
        if let cached = performanceCache[key] { return cached }
        let result = history.lastPerformance(of: item.exerciseID, onEquipment: item.gymEquipmentID)
        performanceCache[key] = result
        return result
    }

    /// De grijze "vorige keer"-waarde voor een set.
    func placeholder(for item: SessionExercise, set workoutSet: WorkoutSet) -> SetPlaceholder {
        let pool = lastPerformance(for: item).filter { $0.isWarmup == workoutSet.isWarmup }
        guard !pool.isEmpty,
              let index = item.sets.firstIndex(where: { $0.id == workoutSet.id }) else { return SetPlaceholder() }
        let position = item.sets[..<index].filter { $0.isWarmup == workoutSet.isWarmup }.count
        let source = pool[min(position, pool.count - 1)]

        var weight = source.weight
        let scale = weightScale(for: item)
        if let value = weight, scale.isConstrained { weight = scale.snap(value) }
        return SetPlaceholder(weight: weight, reps: source.reps)
    }

    func swapOptions(for sessionExerciseID: UUID) -> SwapOptions? {
        guard let item = session.exercises.first(where: { $0.id == sessionExerciseID }),
              let current = library[item.exerciseID] else { return nil }
        let inWorkout = Set(session.exercises.map { $0.exerciseID })
        let suggester = AlternativeSuggester(library: library, gym: gym)
        let preferred = suggester.preferred(for: current, excluding: inWorkout)
        let suggestions = suggester
            .suggestions(for: current, excluding: inWorkout, limit: 5)
            .filter { $0.id != preferred?.exercise.id }
        return SwapOptions(current: current, suggestions: suggestions, preferred: preferred)
    }

    var summaryText: String {
        let sets = session.completedWorkingSetCount
        let volume = Format.weight(session.totalVolume)
        return "\(sets) sets · \(volume) kg volume · \(Format.clock(session.elapsed()))"
    }

    // MARK: - Schrijven

    private func mutate(_ change: (inout ActiveWorkoutSession) -> Void) {
        guard !isClosed else { return }
        var copy = session
        change(&copy)
        session = copy
        store.persist(activeSession: copy)
    }

    private func rebuildRecords() {
        records = PRService.records(from: store.data.history + [session])
    }

    func setWeight(_ setID: UUID, _ value: Double?) {
        guard let loc = session.location(ofSet: setID) else { return }
        let wasCompleted = session.exercises[loc.exercise].sets[loc.set].isCompleted
        mutate { $0.exercises[loc.exercise].sets[loc.set].weight = value }
        if wasCompleted { rebuildRecords() }
    }

    func setReps(_ setID: UUID, _ value: Int?) {
        guard let loc = session.location(ofSet: setID) else { return }
        let wasCompleted = session.exercises[loc.exercise].sets[loc.set].isCompleted
        mutate { $0.exercises[loc.exercise].sets[loc.set].reps = value }
        if wasCompleted { rebuildRecords() }
    }

    /// +/- knop voor gewicht: springt naar de eerstvolgende geldige stap van dít apparaat.
    func stepWeight(_ setID: UUID, up: Bool) {
        guard let loc = session.location(ofSet: setID) else { return }
        let item = session.exercises[loc.exercise]
        let workoutSet = item.sets[loc.set]
        let scale = weightScale(for: item)
        let hint = placeholder(for: item, set: workoutSet)

        let newValue: Double
        if let current = workoutSet.weight ?? hint.weight {
            newValue = scale.step(from: current, up: up)
        } else if up {
            newValue = scale.validWeights().first ?? scale.increment
        } else {
            return
        }
        Haptics.tap()
        setWeight(setID, newValue)
    }

    func stepReps(_ setID: UUID, up: Bool) {
        guard let loc = session.location(ofSet: setID) else { return }
        let item = session.exercises[loc.exercise]
        let workoutSet = item.sets[loc.set]
        let hint = placeholder(for: item, set: workoutSet)

        let newValue: Int
        if let current = workoutSet.reps ?? hint.reps {
            newValue = max(1, current + (up ? 1 : -1))
        } else if up {
            newValue = item.targetRepsMin
        } else {
            return
        }
        Haptics.tap()
        setReps(setID, newValue)
    }

    /// Afvinken (of weer ongedaan maken). Lege velden worden gevuld met de grijze placeholder.
    func toggleComplete(_ setID: UUID) {
        guard let loc = session.location(ofSet: setID) else { return }
        let item = session.exercises[loc.exercise]
        let workoutSet = item.sets[loc.set]

        if workoutSet.isCompleted {
            mutate { $0.exercises[loc.exercise].sets[loc.set].timestamp = nil }
            rebuildRecords()
            return
        }

        let hint = placeholder(for: item, set: workoutSet)
        let scale = weightScale(for: item)
        // Lichaamsgewicht-oefeningen mogen zonder extra gewicht (0). Voor alle andere is een gewicht nodig.
        let fallbackWeight: Double? = scale.kind == .bodyweight ? 0 : nil
        let resolvedWeight: Double? = workoutSet.weight ?? hint.weight ?? fallbackWeight
        guard let weight = resolvedWeight,
              let reps = workoutSet.reps ?? hint.reps,
              reps > 0 else {
            flashAttention(setID)
            return
        }

        var completed = workoutSet
        completed.weight = weight
        completed.reps = reps
        completed.timestamp = Date()

        let broken = completed.isWarmup ? [] : PRService.newRecords(for: completed, against: records)
        PRService.absorb(completed, into: &records)
        mutate { $0.exercises[loc.exercise].sets[loc.set] = completed }

        if broken.isEmpty {
            Haptics.tap()
        } else {
            Haptics.success()
            showPR(kinds: broken, exercise: item, weight: weight, reps: reps)
        }

        if let next = session.nextSupersetTarget(afterCompleting: setID) {
            scrollTarget = next.setID
        } else if session.shouldStartRest(afterCompleting: setID) {
            let seconds = completed.isWarmup ? min(60, item.restSeconds / 2) : item.restSeconds
            let name = exercise(for: item)?.name ?? "Rust"
            startRest(seconds: seconds, label: name)
        }
    }

    func addSet(to sessionExerciseID: UUID, warmup: Bool = false) {
        mutate { $0.addSet(toExercise: sessionExerciseID, isWarmup: warmup) }
        Haptics.tap()
    }

    func removeSet(_ setID: UUID) {
        mutate { $0.removeSet(setID) }
        rebuildRecords()
    }

    func toggleWarmupFlag(_ setID: UUID) {
        guard let loc = session.location(ofSet: setID),
              !session.exercises[loc.exercise].sets[loc.set].isCompleted else { return }
        mutate { $0.exercises[loc.exercise].sets[loc.set].isWarmup.toggle() }
    }

    func toggleWarmupEntry(_ id: UUID) {
        guard let index = session.warmup.firstIndex(where: { $0.id == id }) else { return }
        mutate { $0.warmup[index].isDone.toggle() }
        Haptics.tap()
    }

    func addExercise(_ exercise: Exercise) {
        let equipment = gym?.equipment(forTypeID: exercise.equipmentTypeID).first
        mutate { $0.addExercise(exercise, gymEquipmentID: equipment?.id, restSeconds: exercise.defaultRestSeconds) }
        scrollTarget = session.exercises.last?.sets.first?.id
    }

    func removeExercise(_ sessionExerciseID: UUID) {
        mutate { $0.removeExercise(sessionExerciseID) }
        rebuildRecords()
    }

    func swapExercise(_ sessionExerciseID: UUID, to exercise: Exercise) {
        mutate { $0.swapExercise(sessionExerciseID, to: exercise, gym: gym) }
        Haptics.success()
    }

    func linkWithPrevious(_ sessionExerciseID: UUID) {
        mutate { $0.linkWithPrevious(sessionExerciseID) }
    }

    func unlinkSuperset(_ sessionExerciseID: UUID) {
        mutate { $0.unlinkSuperset(sessionExerciseID) }
    }

    // MARK: - Afronden

    func finish() {
        cancelRest()
        isClosed = true
        if session.completedWorkingSetCount > 0 {
            store.finishActiveSession(session)
        } else {
            store.discardActiveSession()
        }
        Haptics.success()
    }

    func discard() {
        cancelRest()
        isClosed = true
        store.discardActiveSession()
    }

    // MARK: - Rusttimer

    func startRest(seconds: Int, label: String) {
        guard seconds > 0 else { return }
        restTicker?.invalidate()
        let end = Date().addingTimeInterval(TimeInterval(seconds))
        restTimer = RestTimerState(endsAt: end, totalSeconds: seconds, label: label)
        RestNotifier.schedule(after: seconds, body: label)
        scheduleTicker(fireAt: end)
    }

    func adjustRest(by delta: Int) {
        guard var timer = restTimer, !timer.isFinished else { return }
        let newEnd = timer.endsAt.addingTimeInterval(TimeInterval(delta))
        if newEnd.timeIntervalSinceNow <= 1 {
            skipRest()
            return
        }
        timer.endsAt = newEnd
        timer.totalSeconds = max(1, timer.totalSeconds + delta)
        restTimer = timer
        RestNotifier.schedule(after: Int(newEnd.timeIntervalSinceNow), body: timer.label)
        scheduleTicker(fireAt: newEnd)
        Haptics.tap()
    }

    func skipRest() {
        cancelRest()
    }

    private func cancelRest() {
        restTicker?.invalidate()
        restTicker = nil
        restTimer = nil
        RestNotifier.cancel()
    }

    private func scheduleTicker(fireAt end: Date) {
        restTicker?.invalidate()
        let timer = Timer(fire: end, interval: 0, repeats: false) { [weak self] _ in
            self?.restDidFinish()
        }
        RunLoop.main.add(timer, forMode: .common)
        restTicker = timer
    }

    private func restDidFinish() {
        guard var timer = restTimer, !timer.isFinished else { return }
        let overdue = Date().timeIntervalSince(timer.endsAt)
        timer.isFinished = true
        restTimer = timer
        RestNotifier.cancel()
        // Als de app lang op de achtergrond stond, is een haptic nu niet meer zinvol.
        if overdue < 5 { Haptics.success() }

        let id = timer.id
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in
            if self?.restTimer?.id == id { self?.restTimer = nil }
        }
    }

    // MARK: - Meldingen in beeld

    private func showPR(kinds: [PRKind], exercise item: SessionExercise, weight: Double, reps: Int) {
        let name = exercise(for: item)?.name ?? "Oefening"
        let text: String
        if kinds.contains(.heaviestWeight) {
            text = "Nieuw PR · \(name): \(Format.weight(weight)) kg × \(reps)"
        } else if let estimate = E1RM.epley(weight: weight, reps: reps) {
            text = "Nieuw PR · \(name): geschatte 1RM \(Format.weight(estimate)) kg"
        } else {
            text = "Nieuw PR · \(name)"
        }
        prBanner = text
        let token = UUID()
        prBannerToken = token
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) { [weak self] in
            guard let self = self, self.prBannerToken == token else { return }
            self.prBanner = nil
        }
    }

    private func flashAttention(_ setID: UUID) {
        Haptics.warning()
        attentionSetID = setID
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
            if self?.attentionSetID == setID { self?.attentionSetID = nil }
        }
    }
}
