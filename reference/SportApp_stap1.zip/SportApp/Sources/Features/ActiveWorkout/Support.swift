import SwiftUI
import UIKit
import UserNotifications

/// Haptische feedback via UIKit (de SwiftUI-modifier `.sensoryFeedback` is iOS 17+).
enum Haptics {
    static func tap() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func success() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    static func warning() {
        UINotificationFeedbackGenerator().notificationOccurred(.warning)
    }
}

/// Lokale melding voor het einde van de rust, voor als de app op de achtergrond staat of het scherm op slot zit.
/// De eerste keer vraagt iOS om toestemming.
enum RestNotifier {
    private static let identifier = "rest-timer"

    static func schedule(after seconds: Int, body: String) {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound]) { granted, _ in
            guard granted else { return }
            let content = UNMutableNotificationContent()
            content.title = "Rust voorbij"
            content.body = body
            content.sound = .default
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: TimeInterval(max(1, seconds)), repeats: false)
            center.removePendingNotificationRequests(withIdentifiers: [identifier])
            center.add(UNNotificationRequest(identifier: identifier, content: content, trigger: trigger))
        }
    }

    static func cancel() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [identifier])
    }
}

enum Format {
    /// 62.5 → "62,5" (of "62.5", afhankelijk van de taalinstelling). Geen overbodige nullen.
    static func weight(_ value: Double) -> String {
        value.formatted(.number.grouping(.never).precision(.fractionLength(0...2)))
    }

    /// 3725 → "1:02:05", 125 → "2:05"
    static func clock(_ seconds: TimeInterval) -> String {
        let total = Int(max(0, seconds))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        if hours > 0 { return String(format: "%d:%02d:%02d", hours, minutes, secs) }
        return String(format: "%d:%02d", minutes, secs)
    }

    static func remainingText(_ seconds: TimeInterval) -> String {
        if seconds < 45 { return "bijna klaar" }
        let minutes = max(1, Int((seconds / 60).rounded()))
        return "nog ± \(minutes) min"
    }
}
