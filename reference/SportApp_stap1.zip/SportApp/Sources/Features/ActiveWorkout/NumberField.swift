import SwiftUI
import UIKit

/// Numeriek invoerveld voor gewicht en reps.
/// - selecteert de hele waarde zodra je erop tikt (overtikken zonder backspace)
/// - toetsenbord met "Klaar"-knop
/// - toont een grijze placeholder (de waarde van vorige keer) zolang het veld leeg is
struct NumberField: UIViewRepresentable {
    @Binding var value: Double?
    var placeholder: String
    var maxFractionDigits: Int = 2

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> UITextField {
        let field = UITextField()
        field.keyboardType = maxFractionDigits == 0 ? .numberPad : .decimalPad
        field.textAlignment = .center
        field.font = UIFont.monospacedDigitSystemFont(ofSize: 20, weight: .semibold)
        field.adjustsFontSizeToFitWidth = true
        field.minimumFontSize = 12
        field.borderStyle = .none
        field.delegate = context.coordinator
        field.addTarget(context.coordinator,
                        action: #selector(Coordinator.editingChanged(_:)),
                        for: .editingChanged)
        field.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        toolbar.items = [
            UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil),
            UIBarButtonItem(title: "Klaar", style: .done, target: field, action: #selector(UIResponder.resignFirstResponder))
        ]
        field.inputAccessoryView = toolbar
        return field
    }

    func updateUIView(_ field: UITextField, context: Context) {
        context.coordinator.parent = self
        field.attributedPlaceholder = NSAttributedString(
            string: placeholder,
            attributes: [.foregroundColor: UIColor.placeholderText]
        )
        field.textColor = .label
        // Niet overschrijven terwijl je typt, anders springt de cursor.
        if !field.isFirstResponder {
            field.text = value.map { context.coordinator.format($0) }
        }
    }

    final class Coordinator: NSObject, UITextFieldDelegate {
        var parent: NumberField

        init(_ parent: NumberField) {
            self.parent = parent
        }

        func format(_ number: Double) -> String {
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            formatter.minimumFractionDigits = 0
            formatter.maximumFractionDigits = parent.maxFractionDigits
            formatter.usesGroupingSeparator = false
            return formatter.string(from: NSNumber(value: number)) ?? "\(number)"
        }

        @objc func editingChanged(_ field: UITextField) {
            let raw = (field.text ?? "")
                .replacingOccurrences(of: ",", with: ".")
                .trimmingCharacters(in: .whitespaces)
            parent.value = raw.isEmpty ? nil : Double(raw)
        }

        func textFieldDidBeginEditing(_ field: UITextField) {
            DispatchQueue.main.async { field.selectAll(nil) }
        }

        func textFieldDidEndEditing(_ field: UITextField) {
            field.text = parent.value.map { format($0) }
        }
    }
}
