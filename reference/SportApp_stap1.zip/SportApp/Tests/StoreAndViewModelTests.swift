import XCTest
@testable import Sport_App   // pas aan als je project een andere naam heeft (spaties worden underscores)

// MARK: - Opslag

final class WorkoutStoreTests: XCTestCase {

    private func tempURL() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("sportapp-test-\(UUID().uuidString).json")
    }

    private func emptySeed() -> AppData {
        AppData(version: 1, exercises: [], gyms: [], activeGymID: nil, templates: [], history: [], activeSession: nil)
    }

    func testStartAndFinishWorkout() {
        let store = WorkoutStore(fileURL: nil, seed: MockData.appData())
        let startingHistory = store.data.history.count
        XCTAssertNil(store.activeSession)

        store.startSession(template: store.templates[0])
        XCTAssertEqual(store.activeSession?.name, "Push A")

        guard let session = store.activeSession else { return XCTFail("Geen lopende workout") }
        store.finishActiveSession(session)
        XCTAssertNil(store.activeSession)
        XCTAssertEqual(store.data.history.count, startingHistory + 1)
        XCTAssertNotNil(store.data.history.last?.endedAt)
    }

    func testRunningWorkoutSurvivesRestart() {
        let url = tempURL()
        defer { try? FileManager.default.removeItem(at: url) }

        let first = WorkoutStore(fileURL: url, seed: MockData.appData())
        first.startSession(template: first.templates[0])
        first.waitUntilSaved()

        let second = WorkoutStore(fileURL: url, seed: emptySeed())
        XCTAssertEqual(second.activeSession?.name, "Push A", "Na een crash kun je je workout hervatten")
        XCTAssertEqual(second.data.history.count, 2)
        XCTAssertFalse(second.library.all.isEmpty)
    }

    func testUnreadableFileIsKeptAndReplacedBySeed() throws {
        let url = tempURL()
        try Data("dit is geen json".utf8).write(to: url)
        defer {
            try? FileManager.default.removeItem(at: url)
            let directory = url.deletingLastPathComponent()
            let leftovers = (try? FileManager.default.contentsOfDirectory(atPath: directory.path)) ?? []
            for name in leftovers where name.hasPrefix(url.deletingPathExtension().lastPathComponent) {
                try? FileManager.default.removeItem(at: directory.appendingPathComponent(name))
            }
        }

        let store = WorkoutStore(fileURL: url, seed: MockData.appData())
        store.waitUntilSaved()
        XCTAssertEqual(store.data.history.count, 2, "Terugvallen op de startdata")

        let directory = url.deletingLastPathComponent()
        let names = (try? FileManager.default.contentsOfDirectory(atPath: directory.path)) ?? []
        let prefix = url.deletingPathExtension().lastPathComponent
        XCTAssertTrue(names.contains { $0.hasPrefix(prefix) && $0.contains("broken") },
                      "Het onleesbare bestand moet bewaard blijven, niet stilletjes verdwijnen")
    }
}

// MARK: - ViewModel (draait het beste in de simulator, met de app als host)

final class ActiveWorkoutViewModelTests: XCTestCase {

    private func makeViewModel(template: Int = 0) -> ActiveWorkoutViewModel {
        let store = WorkoutStore(fileURL: nil, seed: MockData.appData())
        store.startSession(template: store.templates[template])
        return ActiveWorkoutViewModel(store: store)
    }

    func testPlusMinusSkipsWeightsThatDoNotExistOnThisMachine() {
        let vm = makeViewModel()
        let setID = vm.session.exercises[0].sets[0].id   // chest press, vorige keer 55 kg

        vm.stepWeight(setID, up: true)
        XCTAssertEqual(vm.session.exercises[0].sets[0].weight, 65, "Na 55 komt 65 (60 bestaat niet)")

        vm.stepWeight(setID, up: false)
        vm.stepWeight(setID, up: false)
        XCTAssertEqual(vm.session.exercises[0].sets[0].weight, 45, "Terug: 55, dan 45 (50 bestaat niet)")
    }

    func testCompletingAnEmptySetUsesThePlaceholder() {
        let vm = makeViewModel()
        let setID = vm.session.exercises[0].sets[0].id

        vm.toggleComplete(setID)

        let done = vm.session.exercises[0].sets[0]
        XCTAssertTrue(done.isCompleted)
        XCTAssertEqual(done.weight, 55)
        XCTAssertEqual(done.reps, 10)
        XCTAssertNotNil(vm.restTimer, "Na een gewone oefening start de rusttimer")

        vm.skipRest()
        XCTAssertNil(vm.restTimer)
    }

    func testSupersetSkipsRestAndScrollsToTheNextExercise() {
        let vm = makeViewModel()                              // Push A: oefening 3 en 4 vormen een superset
        let first = vm.session.exercises[2].sets[0].id
        let partner = vm.session.exercises[3].sets[0].id

        // Beide oefeningen hebben historie, dus afvinken werkt met één tik (waarden komen uit de placeholders).
        vm.toggleComplete(first)

        XCTAssertNil(vm.restTimer, "Geen rust tussen de oefeningen van een superset")
        XCTAssertEqual(vm.scrollTarget, partner)

        vm.toggleComplete(partner)
        XCTAssertNotNil(vm.restTimer, "Rust start na de laatste oefening van de ronde")
        vm.skipRest()
    }

    func testEmptySetWithoutAnyHintIsNotCompleted() {
        let vm = makeViewModel()
        // "Kabel crunch" (nooit gedaan) toevoegen: geen placeholder, geen ingevulde waarden.
        let library = vm.library
        guard let crunch = library.all.first(where: { $0.name == "Kabel crunch" }) else { return XCTFail("Mock mist Kabel crunch") }
        vm.addExercise(crunch)
        guard let last = vm.session.exercises.last else { return XCTFail("Oefening niet toegevoegd") }

        vm.toggleComplete(last.sets[0].id)

        XCTAssertFalse(vm.session.exercises.last?.sets[0].isCompleted ?? true,
                       "Zonder gewicht en reps mag een set niet als gedaan tellen")
        XCTAssertNotNil(vm.attentionSetID)
    }

    func testSwapDuringWorkoutKeepsFilledSets() {
        let vm = makeViewModel()
        let item = vm.session.exercises[0]
        vm.setReps(item.sets[0].id, 8)
        vm.setWeight(item.sets[0].id, 45)
        vm.toggleComplete(item.sets[0].id)
        vm.skipRest()

        guard let options = vm.swapOptions(for: item.id) else { return XCTFail("Geen wissel-opties") }
        XCTAssertNotNil(options.suggestions.first, "Er is altijd een app-suggestie voor chest press")
        guard let preferred = options.preferred?.exercise else { return XCTFail("Voorkeur ontbreekt") }

        vm.swapExercise(item.id, to: preferred)

        let swapped = vm.session.exercises[0]
        XCTAssertEqual(swapped.exerciseID, preferred.id)
        XCTAssertEqual(swapped.sets.count, item.sets.count)
        XCTAssertTrue(swapped.sets[0].isCompleted)
        XCTAssertEqual(swapped.sets[0].exerciseID, item.exerciseID)
    }

    func testFinishMovesTheWorkoutIntoHistory() {
        let store = WorkoutStore(fileURL: nil, seed: MockData.appData())
        store.startSession(template: store.templates[0])
        let vm = ActiveWorkoutViewModel(store: store)
        vm.toggleComplete(vm.session.exercises[0].sets[0].id)
        vm.skipRest()

        vm.finish()

        XCTAssertNil(store.activeSession)
        XCTAssertEqual(store.data.history.count, 3)
    }
}
