# Sport App – stap 1: datalaag + actief workout-scherm

Minimalistische workout-tracker in SwiftUI. Gebouwd voor **Xcode 14.2 / iOS 16** (geen iOS 17-API's).

## Belangrijk om eerst te weten

- Deze code is **niet gecompileerd**: ik had geen Xcode of Swift-compiler tot mijn beschikking. Ik heb alles
  regel voor regel nagelopen en dingen gevonden en gerepareerd, maar reken op hooguit een paar kleine
  compileerfouten. Plak de exacte Xcode-foutmelding in de chat, dan los ik het op.
- De unit tests zijn ook niet uitgevoerd. Ze staan klaar zodat jij (⌘U) kunt zien of de berekeningen kloppen.

## Installeren in je bestaande project "Sport App"

1. Open het project in Xcode 14.2.
2. Verwijder het door Xcode gemaakte `ContentView.swift` (rechtsklik > Delete > Move to Trash).
   Laat `Sport_AppApp.swift` staan; die toont `ContentView()` en mag zo blijven.
3. Pak de zip uit. Sleep de map **`Sources`** in de projectnavigator (links) naar de map "Sport App".
   Vink aan: *Copy items if needed*, *Create groups* en target *Sport App*.
4. Controleer bij het project > General > *Minimum Deployments* dat iOS 16.0 (of 16.2) staat.
5. Kies bovenin een simulator (bijv. **iPhone 14 Pro** of **iPhone SE**) en druk op ▶ (⌘R).

De app maakt bij de eerste start voorbeelddata aan (zie "Mock-data"). Wil je opnieuw beginnen: verwijder de app uit de simulator.

## Tests draaien (optioneel)

1. File > New > Target > iOS > **Unit Testing Bundle**, naam "Sport AppTests".
2. Verwijder het voorbeeldbestand dat Xcode maakt en sleep de twee bestanden uit `Tests` erin.
3. ⌘U. Heet je module anders dan `Sport_App`, pas dan de regel `@testable import Sport_App` aan.

De ViewModel-tests draaien het beste in de simulator (de testbundel gebruikt je app als host).

## Wat zit erin

```
Sources/
  Domain/     Pure Swift (alleen Foundation), geen UI. Hier zit de logica.
    WeightScale        geldige gewichten per apparaat: min/max/stap, onregelmatige lijst, pinplaatje, snap/next/previous
    Gym                GymProfile, GymEquipment + ScanMetadata (rawScannedText, detectedIncrements) voor de latere foto-scan
    EquipmentType      soorten apparaten (catalogus)
    Exercise           oefening + ExerciseLibrary (zoeken)
    WorkoutTemplate    schema met optionele warming-up en superset-groepen
    WorkoutSession     ActiveWorkoutSession, WorkoutSet, supersets, "machine bezet"-wissel
    WorkoutHistory     "vorige keer"-waarden (zelfde machine eerst)
    PersonalRecords    PR's (zwaarste gewicht, geschatte 1RM via Epley)
    DurationEstimator  geschatte resterende tijd
    AlternativeSuggester  alternatieven voor "machine bezet" (alleen wat jouw gym heeft)
  Data/
    WorkoutStore       opslag: Codable + één JSON-bestand, autosave na elke set, onleesbaar bestand wordt bewaard
    MockData           oefeningen, een gym, 3 schema's en 2 eerdere workouts
  App/
    ContentView        startscherm
  Features/ActiveWorkout/
    ActiveWorkoutView + ViewModel, ExerciseCardView (supersets), SetRowView, NumberField,
    WarmupSectionView, QuickSwapSheetView (+ zoeklijst), RestTimerView
Tests/
```

## Keuzes die je moet kennen

- **Codable + JSON in plaats van Core Data.** Een Core Data-model (`.xcdatamodeld`) kan ik zonder Xcode niet betrouwbaar
  maken. De rest van de app praat alleen met `WorkoutStore`, dus vervangen door Core Data kan later zonder de schermen aan te raken.
- **Gewichtsstappen horen bij het apparaat in jouw gym**, niet bij de oefening. De +/- knoppen springen alleen naar gewichten
  die dat apparaat echt heeft (in de mock-data: chest press gaat 45 → 55 → 65).
- **"Machine bezet"** laat afgeronde sets bij hun oorspronkelijke oefening staan en verplaatst alleen de open sets.
  Een al ingetypt gewicht wordt afgerond op de stappen van de nieuwe machine.
- **Rusttimer**: start na het afvinken; bij een superset pas na de laatste oefening van de ronde. Haptiek via UIKit
  (`.sensoryFeedback` is iOS 17+). Voor het einde van de rust op de achtergrond is er een lokale melding (iOS vraagt om toestemming).

## Mock-data

- Gym "Mijn gym": stang, dumbbells, kabelstation, chest press (onregelmatige stapel), pec deck, lat pulldown, seated row,
  leg press, leg extension, leg curl, kuitmachine. Bewust **geen** shoulder press machine en row machine: zo zie je dat
  alternatieven worden gefilterd op wat jouw gym heeft.
- Schema's: Push A (met superset), Pull A (met superset), Benen (zonder warming-up).
- Twee eerdere Push A-workouts, dus je ziet meteen grijze placeholders en kunt PR's breken.

## Nog niet gebouwd (volgende stappen)

1. Scherm om je gym en apparaten aan te vinken en gewichtsstappen in te stellen (de datastructuur staat al klaar).
2. Progressie-scherm (PR's en volume per spiergroep).
3. Creatine-reminder (lokale melding, dagelijks).
4. Schema-editor.
5. Foto/scan van apparaten (Vision/OCR) met correctie-flow.
